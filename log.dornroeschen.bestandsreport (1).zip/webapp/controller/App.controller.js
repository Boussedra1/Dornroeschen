sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("puc.log.dornroeschen.bestandsreport.controller.App", {
		onInit: function () {

		}
	});
});


