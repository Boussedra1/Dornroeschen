
sap.ui.define([

	"./BaseController",
/*	"sap/ui/model/Filter",	
	"sap/ui/model/FilterOperator",	*/
	"sap/m/MessageToast"
], function (BaseController, MessageToast) {
	"use strict";

	return BaseController.extend("puc.log.dornroeschen.bestandsreport.controller.Start", {

		onInit: function () {
			 this.oRouter = this.getOwnerComponent().getRouter();
			this.getRouter().getRoute("Start").attachMatched(this.initView, this);
		},
		initView: function (oEvent) {
			var oView = this.getView();
			var oModel = oView.getModel();

			var oMessageManager = sap.ui.getCore().getMessageManager();
			oView.setModel(oMessageManager.getMessageModel(), "message");
			oMessageManager.registerObject(oView, true);

			this._oMessageManager = sap.ui.getCore().getMessageManager();
			this._oMessageManager.registerMessageProcessor(oModel);
		
			
		},
		
		onCliPress: function (oEvent) {
			this.getRouter().navTo("Details");
			
		}
		
	});
});