sap.ui.define([
	"puc/log/dornroeschen/bestandsreport/test/unit/controller/App.controller"
], function () {
	"use strict";
});