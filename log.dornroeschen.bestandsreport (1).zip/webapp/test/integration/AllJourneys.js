/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"puc/log/dornroeschen/bestandsreport/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"puc/log/dornroeschen/bestandsreport/test/integration/pages/App",
	"puc/log/dornroeschen/bestandsreport/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "puc.log.dornroeschen.bestandsreport.view.",
		autoWait: true
	});
});